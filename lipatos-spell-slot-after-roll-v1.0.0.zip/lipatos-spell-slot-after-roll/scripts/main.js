const MODULE_ID = "lipatos-spell-slot-after-roll";

const isPlayer = () => !!game.user && !game.user.isGM;
const text = el => (el?.textContent ?? "").replace(/\s+/g, " ").trim().toLowerCase();

function getRoot(app, html) {
  if (html instanceof HTMLElement) return html;
  if (html?.[0] instanceof HTMLElement) return html[0];
  if (app?.element instanceof HTMLElement) return app.element;
  if (app?.element?.[0] instanceof HTMLElement) return app.element[0];
  return null;
}

function hide(el) {
  if (!el) return;
  el.style.setProperty("display", "none", "important");
}

/**
 * Для игроков:
 * 1) принудительно оставляем расход ячейки включённым;
 * 2) полностью скрываем блок «РАСХОД».
 *
 * Это тот же принцип, который уже работал в общем моде пользователя.
 */
function patchSpellUseDialog(root) {
  if (!root || !isPlayer()) return;

  // Сначала находим чекбокс «Использовать ячейку?» и включаем его.
  for (const el of root.querySelectorAll("label,legend,h3,h4,span,p,div")) {
    const t = text(el);
    if (!/использовать ячейку|use spell slot|consume spell slot/.test(t)) continue;

    const group = el.closest("fieldset,.form-group,.form-fields,.card,.field,.flexrow") ?? el.parentElement;
    const checkbox = group?.querySelector('input[type="checkbox"]');
    if (checkbox && !checkbox.checked) {
      checkbox.checked = true;
      checkbox.dispatchEvent(new Event("change", { bubbles: true }));
    }
  }

  // Затем скрываем весь fieldset/секцию «РАСХОД».
  for (const el of root.querySelectorAll("legend,h3,h4,label,span,p")) {
    const t = text(el);
    if (t !== "расход" && t !== "consumption") continue;

    const section = el.closest("fieldset,.form-group,.card") ?? el.parentElement;
    if (section) hide(section);
  }
}

function patchApp(app, html) {
  if (!isPlayer()) return;
  const root = getRoot(app, html);
  if (!root) return;

  const run = () => patchSpellUseDialog(root);
  run();

  if (!root._lipatosSpellAfterRollObserver) {
    const observer = new MutationObserver(() => queueMicrotask(run));
    observer.observe(root, { childList: true, subtree: true });
    root._lipatosSpellAfterRollObserver = observer;
  }
}

Hooks.on("renderApplicationV2", patchApp);
Hooks.on("renderActivityUseDialog", patchApp);

// ---------------------------------------------------------------------------
// ОТЛОЖЕННЫЙ РАСХОД ЯЧЕЙКИ ДО РЕАЛЬНОГО БРОСКА
// ---------------------------------------------------------------------------

const pending = new Map();

function activityKey(activity) {
  return `${activity?.actor?.uuid ?? ""}:${activity?.item?.id ?? ""}:${activity?.id ?? ""}`;
}

function snapshotSpellSlots(activity) {
  const actor = activity?.actor;
  if (!actor) return null;
  return {
    actor,
    spells: foundry.utils.deepClone(actor.system?.spells ?? {})
  };
}

function spellSlotsChanged(before, after) {
  if (!before || !after) return false;
  return JSON.stringify(before.spells) !== JSON.stringify(after.spells);
}

async function applySnapshot(snapshot) {
  if (!snapshot?.actor) return;

  const update = {};
  for (const [slot, data] of Object.entries(snapshot.spells ?? {})) {
    if (data && Object.prototype.hasOwnProperty.call(data, "value")) {
      update[`system.spells.${slot}.value`] = data.value;
    }
  }

  if (Object.keys(update).length) {
    await snapshot.actor.update(update, {
      [MODULE_ID]: { deferredSpellSlot: true }
    });
  }
}

// D&D5e 6.x сначала применяет consumption. Мы запоминаем состояние ДО него.
Hooks.on("dnd5e.preActivityConsumption", activity => {
  if (!isPlayer() || activity?.actor?.type !== "character") return;
  activity._lipatosSpellSlotBefore = snapshotSpellSlots(activity);
});

// После штатного consumption запоминаем рассчитанное системой состояние ПОСЛЕ,
// затем сразу возвращаем ячейки к исходному значению.
Hooks.on("dnd5e.postActivityConsumption", async activity => {
  if (!isPlayer() || activity?.actor?.type !== "character") return;

  const before = activity._lipatosSpellSlotBefore;
  delete activity._lipatosSpellSlotBefore;
  if (!before) return;

  const after = snapshotSpellSlots(activity);
  if (!spellSlotsChanged(before, after)) return;

  pending.set(activityKey(activity), {
    before,
    after,
    createdAt: Date.now()
  });

  await applySnapshot(before);
});

// Только после состоявшегося броска применяем то значение ячеек,
// которое D&D5e рассчитала после consumption.
async function commitAfterRoll(subject) {
  if (!isPlayer() || !subject) return;

  const key = activityKey(subject);
  const state = pending.get(key);
  if (!state) return;

  pending.delete(key);
  await applySnapshot(state.after);
}

// Атака и урон — основные броски для заклинаний вроде Ice Knife.
for (const hook of [
  "dnd5e.rollAttack",
  "dnd5e.rollAttackV2",
  "dnd5e.rollDamage",
  "dnd5e.rollDamageV2"
]) {
  Hooks.on(hook, async (rolls, data) => {
    if (rolls?.length) await commitAfterRoll(data?.subject);
  });
}

// Универсальный путь для других бросков D&D5e, когда система передаёт activity как subject.
Hooks.on("dnd5e.postRollConfiguration", async (rolls, config) => {
  if (rolls?.length && config?.subject) {
    await commitAfterRoll(config.subject);
  }
});

// Если игрок закрыл окно броска, consumption уже был откатан выше.
// Просто удаляем забытые ожидания через 10 минут.
setInterval(() => {
  const now = Date.now();
  for (const [key, state] of pending) {
    if (now - state.createdAt > 10 * 60 * 1000) pending.delete(key);
  }
}, 60 * 1000);

Hooks.once("ready", () => {
  console.log(`${MODULE_ID} | Ready`);
});
